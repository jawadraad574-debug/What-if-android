-- WHAT IF initial database schema (Supabase / PostgreSQL)
-- Apply only after creating a new Supabase project and reviewing these policies.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  preferred_language text not null default 'ar' check (preferred_language in ('ar','en')),
  created_at timestamptz not null default now()
);

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete restrict,
  category text not null check (category in ('property','car')),
  title text not null,
  description text,
  country_code text,
  city text,
  price numeric(14,2) check (price is null or price >= 0),
  currency text not null default 'AED',
  source_status text not null default 'seller_provided'
    check (source_status in ('verified','seller_provided','estimated')),
  status text not null default 'draft'
    check (status in ('draft','pending_review','published','rejected','sold','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.listing_media (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  storage_path text not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.listing_verifications (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  checked_by uuid references auth.users(id) on delete set null,
  check_type text not null,
  evidence_note text,
  evidence_reference text,
  result text not null check (result in ('passed','failed','inconclusive')),
  checked_at timestamptz not null default now()
);

create table if not exists public.favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  listing_id uuid not null references public.listings(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, listing_id)
);

alter table public.profiles enable row level security;
alter table public.listings enable row level security;
alter table public.listing_media enable row level security;
alter table public.listing_verifications enable row level security;
alter table public.favorites enable row level security;

-- Users can read and update only their own profile.
create policy "profile_select_own" on public.profiles
for select using (auth.uid() = id);
create policy "profile_insert_own" on public.profiles
for insert with check (auth.uid() = id);
create policy "profile_update_own" on public.profiles
for update using (auth.uid() = id) with check (auth.uid() = id);

-- Public can read published listings. Owners can manage their own listings.
create policy "listings_read_published_or_owner" on public.listings
for select using (status = 'published' or auth.uid() = owner_id);
create policy "listings_insert_owner" on public.listings
for insert with check (auth.uid() = owner_id);
create policy "listings_update_owner" on public.listings
for update using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

-- Media follows listing visibility/ownership.
create policy "media_read_visible_listing" on public.listing_media
for select using (
  exists (select 1 from public.listings l
          where l.id = listing_id and (l.status = 'published' or l.owner_id = auth.uid()))
);
create policy "media_manage_owner_listing" on public.listing_media
for all using (
  exists (select 1 from public.listings l where l.id = listing_id and l.owner_id = auth.uid())
) with check (
  exists (select 1 from public.listings l where l.id = listing_id and l.owner_id = auth.uid())
);

-- Verification records are readable for published listings; only trusted backend/admin
-- workflows should insert or change them. No client write policy is intentionally added.
create policy "verification_read_visible_listing" on public.listing_verifications
for select using (
  exists (select 1 from public.listings l
          where l.id = listing_id and (l.status = 'published' or l.owner_id = auth.uid()))
);

create policy "favorites_manage_own" on public.favorites
for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
