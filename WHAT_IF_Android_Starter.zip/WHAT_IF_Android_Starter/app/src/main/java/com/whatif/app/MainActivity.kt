package com.whatif.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WhatIfApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WhatIfApp() {
    var english by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf("home") }
    val t: (String, String) -> String = { ar, en -> if (english) en else ar }
    MaterialTheme(colorScheme = lightColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF173B35),
        secondary = androidx.compose.ui.graphics.Color(0xFFC69B55),
        background = androidx.compose.ui.graphics.Color(0xFFF7F6F2)
    )) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("WHAT IF | لو كنت مكاني", fontWeight = FontWeight.Bold) },
                    actions = { TextButton(onClick = { english = !english }) {
                        Text(if (english) "العربية" else "English")
                    } }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = page == "home", onClick = { page = "home" },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text(t("الرئيسية","Home")) })
                    NavigationBarItem(selected = page == "market", onClick = { page = "market" },
                        icon = { Icon(Icons.Default.Search, null) }, label = { Text(t("السوق","Market")) })
                    NavigationBarItem(selected = page == "simulator", onClick = { page = "simulator" },
                        icon = { Icon(Icons.Default.Calculate, null) }, label = { Text(t("المحاكي","Simulator")) })
                    NavigationBarItem(selected = page == "account", onClick = { page = "account" },
                        icon = { Icon(Icons.Default.Person, null) }, label = { Text(t("حسابي","Account")) })
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
                when (page) {
                    "home" -> HomeScreen(t, onMarket = { page = "market" }, onSimulator = { page = "simulator" })
                    "market" -> MarketScreen(t)
                    "simulator" -> SimulatorScreen(t)
                    else -> AccountScreen(t)
                }
            }
        }
    }
}

@Composable
fun HomeScreen(t: (String, String) -> String, onMarket: () -> Unit, onSimulator: () -> Unit) {
    Text(t("قرارك الكبير يستحق مقارنة واضحة","Big decisions deserve clear comparisons"),
        style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    Text(t("نساعدك تقارن قبل ما تشتري — بمعلومات واضحة، ومصادر قابلة للتحقق.",
        "Compare before you buy — with transparent information and verifiable sources."))
    Spacer(Modifier.height(22.dp))
    FeatureCard(t("العقارات","Real estate"), t("قارن الشقق والأسعار والتكاليف","Compare homes, prices and costs"), onMarket)
    FeatureCard(t("السيارات","Cars"), t("قارن الخيارات وتكاليف الملكية","Compare options and ownership costs"), onMarket)
    FeatureCard(t("محاكي القرار","Decision simulator"), t("اختبر قرارك قبل الالتزام","Test your decision before committing"), onSimulator)
    Spacer(Modifier.height(16.dp))
    Text(t("مبدأنا: لا عروض وهمية ولا ادعاء تحقق دون دليل.",
        "Our rule: no fake listings and no verification claims without evidence."),
        color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
}

@Composable
fun FeatureCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 7.dp), onClick = onClick) {
        Column(Modifier.padding(18.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = onClick) { Text("فتح / Open") }
        }
    }
}

@Composable
fun MarketScreen(t: (String, String) -> String) {
    Text(t("السوق","Marketplace"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    Text(t("اختر الفئة لبدء المقارنة.","Choose a category to start comparing."))
    Spacer(Modifier.height(12.dp))
    listOf(t("عقارات للبيع","Property for sale"), t("سيارات للبيع","Cars for sale")).forEach {
        Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text(it, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(t("ستظهر هنا الإعلانات بعد ربط قاعدة البيانات والتحقق من مصدرها.",
                    "Listings will appear here after the database and source checks are connected."))
            }
        }
    }
    Text(t("تنبيه: هذه النسخة لا تعرض إعلانات حقيقية بعد.",
        "Note: this build does not show live listings yet."), color = MaterialTheme.colorScheme.error)
}

@Composable
fun SimulatorScreen(t: (String, String) -> String) {
    var budget by remember { mutableStateOf("100000") }
    var cost by remember { mutableStateOf("2500") }
    val b = budget.toDoubleOrNull() ?: 0.0
    val c = cost.toDoubleOrNull() ?: 0.0
    Text(t("محاكي القرار","Decision simulator"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    Text(t("احسب قدرتك المبدئية على تحمّل القرار.","Estimate your initial ability to afford the decision."))
    Spacer(Modifier.height(16.dp))
    OutlinedTextField(value = budget, onValueChange = { budget = it }, label = { Text(t("المبلغ المتاح (درهم)","Available amount (AED)")) }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(value = cost, onValueChange = { cost = it }, label = { Text(t("التكلفة الشهرية (درهم)","Monthly cost (AED)")) }, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(16.dp))
    val months = if (c > 0) b / c else 0.0
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text(t("مدة التغطية التقديرية","Estimated coverage"), fontWeight = FontWeight.Bold)
            Text(if (c > 0) "%.1f".format(months) + t(" شهر"," months") else "—",
                style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            Text(t("حساب مبسط لا يشمل الطوارئ أو الالتزامات الأخرى. ليس توصية مالية.",
                "Simplified estimate; excludes emergencies and other obligations. Not financial advice."))
        }
    }
}

@Composable
fun AccountScreen(t: (String, String) -> String) {
    Text(t("حسابك","Your account"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    Text(t("تسجيل الدخول والاشتراكات ستُفعّل بعد ربط خدمات الحساب والدفع.",
        "Sign-in and subscriptions will be enabled after account and payment services are connected."))
    Spacer(Modifier.height(12.dp))
    Text(t("الأسعار المقترحة ليست مفعّلة حالياً ولا يوجد دفع إلكتروني في هذه النسخة.",
        "Suggested prices are not active; this build does not process payments."),
        color = MaterialTheme.colorScheme.error)
}
